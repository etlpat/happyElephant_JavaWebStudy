#  English Language Pack for HBuilderX

English Language Pack provides localized UI experience for HBuilderX.

## Contributing

If you'd like to participate in the effort either to contribue translation or improve translation, see [community localization page](https://www.dcloud.io) for more information.

## License

The source code and strings are licensed under the [LICENSE](https://www.dcloud.io/language-pack/LICENSE.md) license.

## Credits

English Language Pack is brought to you through "By the community, for the community" community localization effort.

Special thanks to community contributors for making it available.

